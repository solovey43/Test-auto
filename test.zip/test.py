import pytest
from Calculator import Calculator


class Test_calculator:
    @pytest.fixture
    def calc(self):
        return Calculator()

    @pytest.mark.parametrize("a, b, result", [(3, 5, 8), (2, 6, 8), (10, 4, 14)])
    def test_addition(self, calc, a, b, result):
        assert calc.add(a, b) == result

    @pytest.mark.parametrize("a, b, result", [(10, 4, 6), (8, 3, 5), (20, 7, 13)])
    def test_subtraction(self, calc, a, b, result):
        assert calc.subtract(a, b) == result

    @pytest.mark.parametrize("a, b, result", [(2, 3, 6), (4, 5, 20), (6, 7, 42)])
    def test_multiplication(self, calc, a, b, result):
        assert calc.multiply(a, b) == result

    @pytest.mark.parametrize("a, b, result", [(10, 2, 5), (15, 3, 5), (20, 4, 5)])
    def test_division_positive(self, calc, a, b, result):
        assert calc.divide(a, b) == result

    def test_division_by_zero(self, calc):
        with pytest.raises(ValueError):
            calc.divide(5, 0)
