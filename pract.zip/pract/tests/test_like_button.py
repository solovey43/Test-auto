from selenium.webdriver.common.by import By
from pages.like_button import LikeButton


def test_button2_exist(browser):
    like_button = LikeButton(browser)
    like_button.open()
    assert like_button.button_is_displayed


def test_button2_clicked(browser):
    like_button = LikeButton(browser)
    like_button.open()
    like_button.button_click()
    assert 'Submitted' == like_button.result_text
