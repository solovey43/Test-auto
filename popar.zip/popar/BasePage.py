from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


class BasePage:
    def __init__(self, driver):
        self.driver = driver

    def open_login_page(self):
        self.driver.get("https://www.saucedemo.com")

    LOCATOR_USERNAME = (By.ID, "user-name")
    LOCATOR_PASSWORD = (By.ID, "password")
    LOCATOR_LOGIN_BUTTON = (By.ID, "login-button")

    def find_element(self, locator, timeout=15):
        return WebDriverWait(self.driver, timeout).until(
            EC.visibility_of_element_located(locator)
        )

    def enter_username(self, username):
        username_element = self.find_element(self.LOCATOR_USERNAME)
        WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(username_element))
        username_element.clear()
        username_element.send_keys(username)

    def enter_password(self, password):
        password_element = self.find_element(self.LOCATOR_PASSWORD)
        password_element.clear()
        password_element.send_keys(password)

    def click_login_button(self):
        login_button = self.find_element(self.LOCATOR_LOGIN_BUTTON)
        login_button.click()

    def login(self, username, password):
        if username == "user" and password == "password":
            print("Неверные данные")
        else:
            self.enter_username(username)
            self.enter_password(password)
            self.click_login_button()
            print("Вход в систему")



