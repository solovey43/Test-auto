import pytest
from selenium import webdriver
from BasePage import BasePage

logins = [
    ('standard_user', 'secret_sauce'),
    ('locked_out_user', 'secret_sauce'),
    ('problem_user', 'secret_sauce'),
    ('performance_glitch_user', 'secret_sauce'),
    ('error_user', 'secret_sauce')
]

@pytest.mark.parametrize("username, password", logins)
def test_login_with_valid_credentials(username, password):
    browser = webdriver.Chrome()
    base_page = BasePage(browser)
    base_page.open_login_page()
    base_page.enter_username(username)
    base_page.enter_password(password)
    base_page.click_login_button()



